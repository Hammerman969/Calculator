package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        // for calculator in java

        // 1 take input numbers and and operator from user
        // 2 take result variable and initialize to 0
        // 3 switch based on operator

        Scanner scanner = new Scanner(System.in);
        double number1 = scanner.nextDouble();

        char operator = scanner.next().charAt(0);

        double number2 = scanner.nextDouble();
        double result = 0.0;

        switch (operator){
            case '+':
                result = number1 + number2;
                System.out.println(result);
                break;
            case '-':
                result = number1 - number2;
                System.out.println(result);
                break;
            case '*':
                result = number1 * number2;
                System.out.println(result);
                break;
            case '/':
                result = number1 / number2;
                System.out.println(result);
                break;
                
            default:
                System.out.println("Invalid operator");
                break;
        }
    }
}
